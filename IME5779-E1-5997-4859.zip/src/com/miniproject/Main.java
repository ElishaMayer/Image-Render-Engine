package com.miniproject;

/**
 * Home Work 1.
 * Written by:
 * Elisha Mayer ,319185997 ,elisja.mayer@gmail.com .
 * Menachem Natanson , 207134859, menachem.natanson@gmail.com
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("Hello World!");
    }
}
